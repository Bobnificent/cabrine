<?php return array (
  'software_id' => '0001',
  'name' => 'Default Theme',
  'is_active' => 1,
  'purchase_code' => '',
  'username' => '',
  'image' => 'default-theme.png',
);
